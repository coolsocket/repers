# RePERS Open Source Benchmark

- Generated: `2026-06-23T13:23:07.387381+00:00`
- OK: `True`
- Repositories: `10`
- Source URLs: `10`
- Patterns: `8`
- Benchmark: `/home/sa_114486498687979675637/repers/.repers/docs/open-source-benchmark.json`

## Missing Source Paths

- None

## Missing Installed Paths

- None